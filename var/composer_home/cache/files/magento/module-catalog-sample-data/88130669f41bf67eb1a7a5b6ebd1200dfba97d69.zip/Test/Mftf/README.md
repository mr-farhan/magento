# Catalog Sample Data Functional Tests

The Functional Test Module for **Magento CatalogSampleData** module.
